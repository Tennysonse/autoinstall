from django.db import models

# Create your models here.

class User(models.Model):
  uphone=models.CharField(max_length=11)
  upwd=models.CharField(max_length=30)
  def __str__(self):
    return self.uname

  class Meta:
    db_table = 'user'

class Uplots(models.Model):
  ip=models.CharField(max_length=11)
  plots=models.CharField(max_length=5)
