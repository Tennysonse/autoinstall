$(function(){
    //为　#formReg 绑定　submit 事件
    $("#formReg").submit(function(){
        //判断两次密码输入是否一致
        if($("#upwd").val() != $('#cpwd').val()){
            alert('两次密码不一致，请重新输入')
            return false;
        }

        //判断用户手机号是否已经存在
        if($("#uphone-show").html() == "用户名称已经存在"){
          return false;
        }
        return true;
    });

    //为 name=uphone 的元素绑定 blur 事件
    $("input[name='uphone']").blur(function(){
      // $.get(url,data,callback,type);
      check_phone();
    });
});

/**
 * 验证手机号码是否存在的操作(异步)
 * 返回值:{status:状态码,msg:状态文本}*/
function check_phone(){
  $.get(
    '/checkphone/',
    "uphone="+$("input[name='uphone']").val(),function(data){
      //data : 成功时响应的数据
      data = JSON.parse(data);
      $("#uphone-show").html(data.msg);
    });
}














