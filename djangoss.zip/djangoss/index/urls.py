
from django.urls import path
from .views import *



urlpatterns = [
  path('Chiasummary/plots/',plots_views),
  #path('register',register_views,name='reg'),
  path('login/',login_views),
  #path('chiaMachine/summarys',plots_views),

]